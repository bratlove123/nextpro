import './header.scss';

function Header() {
  return <div className="header">Header hihi!</div>;
}

export default Header;
