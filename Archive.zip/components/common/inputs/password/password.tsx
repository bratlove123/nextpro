import './header.scss';

function Password() {
  return <div className="header">Header hihi!</div>;
}

export default Password;
